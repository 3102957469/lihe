---
name: Task
about: Describe a generic activity we should carry out.
---


__What should we do?__

<!-- Clearly describe the activity we should carry out. -->


__Why should we do it?__

<!-- Argue why doing it is a healthy investment of our time. -->
